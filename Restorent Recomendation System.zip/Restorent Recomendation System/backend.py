from flask import Flask, render_template, request
import pandas as pd

app = Flask(__name__)

# CSV file read
data = pd.read_csv("resto.csv")

@app.route("/", methods=["GET", "POST"])
def home():

    recommendations = []

    if request.method == "POST":

        cuisine = request.form["cuisine"]

        # Filter restaurants
        filtered = data[data["Cuisine"].str.lower() == cuisine.lower()]

        recommendations = filtered.to_dict(orient="records")

    return render_template("index.html", recommendations=recommendations)

if __name__ == "__main__":
    app.run(debug=True)